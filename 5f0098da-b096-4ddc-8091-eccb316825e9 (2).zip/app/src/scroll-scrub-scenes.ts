import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";
export const scrollScrubTheme: ScrollScrubTheme = { accent: "#A4D64C", background: "#0D1219", ink: "#EBF1F5", muted: "#7E8E9E" };
export const scrollScrubScenes: ScrollScrubScene[] = [{
  body: "Describe what you want in plain language, then turn the idea into paste-ready Luau.",
  clip: "/assets/world/scene-01.mp4",
  id: "scene-01", kicker: "Roblox developer cockpit", label: "Generator",
  mobileClip: "/assets/world/scene-01-mobile.mp4", mobilePoster: "/assets/world/scene-01-mobile-poster.png",
  poster: "/assets/world/scene-01-poster.png", tags: ["Luau", "Mobile friendly"], title: "From idea to script."
}];
