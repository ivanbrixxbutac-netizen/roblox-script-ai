import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ScrollScrub } from "@/components/scroll-scrub/scroll-scrub";
import { scrollScrubScenes, scrollScrubTheme } from "@/scroll-scrub-scenes";

export const Route = createFileRoute("/")({ component: Index });

const examples = ["Coin system with leaderstats", "Kill brick that respawns players", "Teleport pad to another part", "Simple shop GUI", "Checkpoint system"];

function buildScript(prompt: string) {
  const p = prompt.toLowerCase();
  if (p.includes("coin") || p.includes("leaderstat")) return [
    'local Players = game:GetService("Players")',
    '',
    'local function setupPlayer(player)',
    '    local leaderstats = Instance.new("Folder")',
    '    leaderstats.Name = "leaderstats"',
    '    leaderstats.Parent = player',
    '',
    '    local coins = Instance.new("IntValue")',
    '    coins.Name = "Coins"',
    '    coins.Value = 0',
    '    coins.Parent = leaderstats',
    'end',
    '',
    'Players.PlayerAdded:Connect(setupPlayer)',
    'for _, player in Players:GetPlayers() do setupPlayer(player) end',
    '',
    '-- Put this Script in ServerScriptService.'
  ].join('\n');
  if (p.includes("kill") || p.includes("damage")) return [
    'local Players = game:GetService("Players")',
    '',
    'local part = script.Parent',
    'local debounce = {}',
    '',
    'part.Touched:Connect(function(hit)',
    '    local character = hit:FindFirstAncestorOfClass("Model")',
    '    local humanoid = character and character:FindFirstChildOfClass("Humanoid")',
    '    if not humanoid or debounce[character] then return end',
    '    debounce[character] = true',
    '    humanoid.Health = 0',
    '    task.delay(1, function() debounce[character] = nil end)',
    'end)',
    '',
    '-- Put this Script inside the damaging Part.'
  ].join('\n');
  if (p.includes("teleport")) return [
    'local Players = game:GetService("Players")',
    '',
    'local pad = script.Parent',
    'local destination = workspace:WaitForChild("Destination")',
    '',
    'pad.Touched:Connect(function(hit)',
    '    local character = hit:FindFirstAncestorOfClass("Model")',
    '    local player = character and Players:GetPlayerFromCharacter(character)',
    '    local root = character and character:FindFirstChild("HumanoidRootPart")',
    '    if player and root then root.CFrame = destination.CFrame + Vector3.new(0, 3, 0) end',
    'end)',
    '',
    '-- Create a Part named Destination in Workspace.',
    '-- Put this Script inside the teleport pad.'
  ].join('\n');
  if (p.includes("checkpoint") || p.includes("obby")) return [
    'local Players = game:GetService("Players")',
    '',
    'local checkpoint = script.Parent',
    'local spawnLocation = checkpoint:FindFirstChildOfClass("SpawnLocation")',
    '',
    'checkpoint.Touched:Connect(function(hit)',
    '    local character = hit:FindFirstAncestorOfClass("Model")',
    '    local player = character and Players:GetPlayerFromCharacter(character)',
    '    if not player or not spawnLocation then return end',
    '    player.RespawnLocation = spawnLocation',
    'end)',
    '',
    '-- Put this Script inside the checkpoint.',
    '-- Add a SpawnLocation as a child of the checkpoint.'
  ].join('\n');
  return [
    '-- Roblox Luau starter generated from your request:',
    '-- ' + prompt.replace(/\n/g, " ").slice(0, 120),
    '',
    'local Players = game:GetService("Players")',
    '',
    'local function setupPlayer(player)',
    '    print("Ready:", player.Name)',
    'end',
    '',
    'Players.PlayerAdded:Connect(setupPlayer)',
    '',
    '-- Add the exact objects, events, and behavior you need.',
    '-- Recommended location: ServerScriptService.'
  ].join('\n');
}

function Index() {
  const [prompt, setPrompt] = useState("");
  const [code, setCode] = useState("-- Your generated Luau script will appear here.");
  const [status, setStatus] = useState("Ready");
  const [mode, setMode] = useState("generate");

  const run = (nextMode: string) => {
    const clean = prompt.trim();
    setMode(nextMode);
    if (!clean) { setStatus("Describe the script you want first."); return; }
    if (nextMode === "generate") setCode(buildScript(clean));
    if (nextMode === "explain") setCode("EXPLANATION\n\nThis request is: " + clean + "\n\nThe workspace creates a Roblox Luau starter and includes placement notes. Check object names in Explorer before testing.");
    if (nextMode === "fix") setCode("FIX WORKFLOW\n\n1. Check the Output window for the first red error.\n2. Confirm every object name matches Explorer.\n3. Confirm the script is in the recommended service.\n4. Paste the error and related code here for a targeted fix.\n\nRequest: " + clean);
    setStatus("Ready to copy.");
  };

  const copy = async () => {
    try { await navigator.clipboard.writeText(code); setStatus("Copied to clipboard."); }
    catch { setStatus("Select the code and copy it manually."); }
  };

  return (
    <main className="rs-page">
      <ScrollScrub scenes={scrollScrubScenes} theme={scrollScrubTheme} />
      <section className="rs-workspace" id="generator">
        <div className="rs-section-head">
          <span className="rs-kicker">SCRIPT WORKSPACE</span>
          <h2>Write what you want. Get the Luau.</h2>
          <p>Generate complete starter scripts, understand what they do, and turn errors into actionable fixes.</p>
        </div>
        <div className="rs-grid">
          <div className="rs-panel rs-prompt">
            <label htmlFor="prompt">Your request</label>
            <textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Example: Make a coin system with leaderstats..." />
            <div className="rs-examples">{examples.map((item) => <button key={item} onClick={() => setPrompt(item)}>{item}</button>)}</div>
            <div className="rs-actions">
              <button className="rs-primary" onClick={() => run("generate")}>Generate Script</button>
              <button className="rs-secondary" onClick={() => run("explain")}>Explain</button>
              <button className="rs-secondary" onClick={() => run("fix")}>Fix Error</button>
            </div>
          </div>
          <div className="rs-panel rs-output">
            <div className="rs-output-head"><span>Luau output</span><button onClick={copy}>Copy Code</button></div>
            <pre><code>{code}</code></pre>
            <div className="rs-status">{status}</div>
          </div>
        </div>
      </section>
      <section className="rs-info">
        <div><span className="rs-kicker">CAPABILITIES</span><h2>Built around real Roblox workflows.</h2></div>
        <div className="rs-cap-grid">
          {[
            ["Systems", "Coins, leaderstats, rounds, checkpoints, doors, teleports, tools."],
            ["UI", "StarterGui flows, buttons, prompts, status panels, and mobile-friendly layouts."],
            ["Debugging", "Explain errors, check placement, and turn Output messages into next steps."],
            ["Placement", "Every starter includes where the Script or LocalScript belongs in Studio."]
          ].map(([title, text]) => <article key={title}><h3>{title}</h3><p>{text}</p></article>)}
        </div>
      </section>
      <section className="rs-guide">
        <div className="rs-guide-card"><span className="rs-kicker">PLACEMENT GUIDE</span><h2>Know where the code goes.</h2><p>ServerScriptService for server logic. StarterGui for interface scripts. ReplicatedStorage for shared ModuleScripts and RemoteEvents. StarterPlayerScripts for client controls.</p></div>
        <div className="rs-code-card"><span>Typical flow</span><pre>{"Prompt\n  ↓\nGenerate\n  ↓\nCopy Code\n  ↓\nPaste into Studio\n  ↓\nTest in Play mode"}</pre></div>
      </section>
      <footer className="rs-footer"><strong>Roblox Script AI</strong><span>Made for Roblox developers.</span></footer>
    </main>
  );
}
