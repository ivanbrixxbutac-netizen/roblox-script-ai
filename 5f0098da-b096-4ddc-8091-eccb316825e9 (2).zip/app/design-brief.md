# Roblox Script AI design brief
Design read: Roblox developers need a fast, focused place to turn plain-language requests into paste-ready Luau.
Concept spine: a compact developer cockpit where an idea moves from prompt to working script.
Delivery tier: cinema.
Animation mode: animated-website
Journey shape: single-shot
Journey: Prompt, Build, Ship. The camera moves from the prompt panel into the code editor and resolves on the generate action.
World grammar: cool slate-black developer workspace, lime accent, thin grid lines, soft panels, centered code surface, stable exposure, restrained motion.
Mobile framing: keep prompt, output, and generate action center-safe.
Locked palette: #0D1219 background, #A4D64C accent, #EBF1F5 ink, #7E8E9E muted.
Locked type: Geist + Geist Mono.
Section plan: hero journey, generator workspace, capability matrix, placement guide, footer.
Asset plan: cinematic workspace film and exact posters, brand OG, favicon. Visual generation was unavailable on this account, so the film is a local fallback matching the locked direction.
CTA inventory: Generate Script, Copy Code, Explain, Fix Error.
